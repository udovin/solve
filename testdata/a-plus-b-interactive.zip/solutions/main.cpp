#include <iostream>

int main() {
    int a, b;
    std::cout << "?" << std::endl;
    std::cin >> a;
    std::cout << "?" << std::endl;
    std::cin >> b;
    std::cout << "! " << a + b << std::endl;
    return 0;
}
