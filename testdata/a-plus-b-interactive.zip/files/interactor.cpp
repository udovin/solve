#include "testlib.h"

#include <iostream>

int main(int argc, char* argv[]) {
    registerInteraction(argc, argv);
    int a = inf.readInt();
    int b = inf.readInt();
    ouf.ensure(ouf.readChar() == '?');
    ouf.readEoln();
    std::cout << a << std::endl;
    ouf.ensure(ouf.readChar() == '?');
    ouf.readEoln();
    std::cout << b << std::endl;
    ouf.ensure(ouf.readChar() == '!');
    int sum = ouf.readInt();
    tout << sum << std::endl;
    quitf(_ok, "sum = %d", sum);
}
